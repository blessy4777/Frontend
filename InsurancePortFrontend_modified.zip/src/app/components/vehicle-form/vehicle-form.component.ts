import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehicleService } from '../../services/vehicle.service';
import { Vehicle } from '../../models/vehicle.model';

@Component({
  selector: 'app-vehicle-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="container mt-4">
    <div class="card mx-auto" style="max-width:800px;">
      <div class="card-header bg-primary text-white">
        <h4 class="mb-0">{{isUpdate ? 'Update Vehicle' : 'Register Vehicle'}}</h4>
      </div>
      <div class="card-body">
        <form (ngSubmit)="save()" #f="ngForm">
          <div class="mb-3">
            <label class="form-label">Owner Name</label>
            <input class="form-control" name="ownerName" [(ngModel)]="vehicle.ownerName" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Vehicle Number</label>
            <input class="form-control" name="vehicleNumber" [(ngModel)]="vehicle.vehicleNumber" required [readonly]="isUpdate">
          </div>
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Brand</label>
              <input class="form-control" name="brand" [(ngModel)]="vehicle.brand">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Model</label>
              <input class="form-control" name="model" [(ngModel)]="vehicle.model">
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">Engine CC</label>
            <input class="form-control" name="engineCc" [(ngModel)]="vehicle.engineCc" type="number">
          </div>
          <div class="d-flex justify-content-between">
            <button class="btn btn-secondary" type="button" (click)="cancel()">Cancel</button>
            <button class="btn btn-success" type="submit" [disabled]="submitting">{{submitting ? 'Saving...' : (isUpdate ? 'Update' : 'Register')}}</button>
          </div>
        </form>

        <div *ngIf="successMessage" class="alert alert-success mt-3">{{successMessage}}</div>
        <div *ngIf="errorMessage" class="alert alert-danger mt-3">{{errorMessage}}</div>
      </div>
    </div>
  </div>
  `
})
export class VehicleFormComponent implements OnInit {
  vehicle: Vehicle = {} as Vehicle;
  submitting = false;
  successMessage = '';
  errorMessage = '';
  isUpdate = false;

  constructor(private vehicleService: VehicleService, private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {
    const vn = this.route.snapshot.queryParamMap.get('vehicleNumber');
    if (vn) {
      this.isUpdate = true;
      this.vehicleService.getByVehicleNumber(vn).subscribe(v => {
        if (v) {
          this.vehicle = v;
        } else {
          // prefill vehicle number for registration
          this.vehicle = { vehicleNumber: vn } as Vehicle;
          this.isUpdate = false;
        }
      });
    }
  }

  save(): void {
    this.errorMessage = '';
    this.successMessage = '';
    this.submitting = true;
    this.vehicleService.saveVehicle(this.vehicle).subscribe({
      next: (saved) => {
        this.submitting = false;
        this.successMessage = 'Vehicle Registered Successfully!';
        // navigate to quotes with vehicleNumber
        const number = (saved && saved.vehicleNumber) ? saved.vehicleNumber : this.vehicle.vehicleNumber;
        this.router.navigate(['/quotes'], { queryParams: { vehicleNumber: number, userId: saved.userId || '' }});
      },
      error: (err) => {
        console.error(err);
        this.submitting = false;
        this.errorMessage = err?.message || 'Registration failed. Please try again.';
      }
    });
  }

  cancel(): void {
    this.router.navigate(['/']);
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../services/admin.service';
import { AuthService } from '../../services/auth.service';
import { AdminApplication } from '../../models/admin-application.model';

@Component({
  selector: 'app-admin-applications',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2>All Insurance Applications</h2>
      <button class="btn btn-danger" (click)="logout()">Logout</button>
    </div>

    <div *ngIf="loading" class="text-center">Loading...</div>
    <div *ngIf="errorMessage" class="alert alert-danger">{{errorMessage}}</div>

    <div *ngIf="applications?.length">
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>ID</th><th>User</th><th>Email</th><th>Vehicle</th><th>Provider</th><th>Plan</th><th>Premium</th><th>KYC</th><th>Applied At</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let app of applications">
              <td>{{app.id || app.applicationId}}</td>
              <td>{{app.userName || app.name}}</td>
              <td>{{app.userEmail || app.email}}</td>
              <td>{{app.vehicleNumber}}</td>
              <td>{{app.selectedProvider}}</td>
              <td>{{app.selectedPlan}}</td>
              <td>{{app.premiumAmount}}</td>
              <td>{{app.kycStatus}}</td>
              <td>{{app.appliedAt}}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div *ngIf="!applications || applications.length===0" class="alert alert-info">No applications found.</div>
  </div>
  `
})
export class AdminApplicationsComponent implements OnInit {
  applications: AdminApplication[] = [];
  loading = false;
  errorMessage = '';

  constructor(private adminService: AdminService, private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.adminService.getAllApplications().subscribe({
      next: (apps) => {
        this.applications = apps || [];
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading applications:', err);
        this.errorMessage = 'Failed to load applications. Please try again.';
        this.loading = false;
      }
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/']);
  }
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehicleService } from '../../services/vehicle.service';
import { Vehicle } from '../../models/vehicle.model';

@Component({
  selector: 'app-vehicle-check',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="container mt-4">
    <div class="card mx-auto" style="max-width:700px;">
      <div class="card-header bg-info text-white"><h5 class="mb-0">Check Vehicle</h5></div>
      <div class="card-body">
        <div class="input-group mb-3">
          <input class="form-control" [(ngModel)]="vehicleNumber" name="vehicleNumber" placeholder="Enter vehicle number">
          <button class="btn btn-primary" (click)="check()">Search</button>
        </div>

        <div *ngIf="loading" class="text-center">Loading...</div>

        <div *ngIf="vehicle" class="card mt-3">
          <div class="card-body text-start">
            <h6>{{vehicle.vehicleNumber}} — {{vehicle.ownerName}}</h6>
            <p class="mb-1"><strong>Brand:</strong> {{vehicle.brand}} <strong class="ms-3">Model:</strong> {{vehicle.model}}</p>
            <div class="mt-2">
              <button class="btn btn-success me-2" (click)="goQuotes()">Get Price / Insurance</button>
              <button class="btn btn-outline-secondary" (click)="edit()">Edit</button>
            </div>
          </div>
        </div>

        <div *ngIf="notFound" class="alert alert-warning mt-3">
          Vehicle not found. <button class="btn btn-sm btn-success ms-2" (click)="register()">Register Vehicle</button>
        </div>
      </div>
    </div>
  </div>
  `
})
export class VehicleCheckComponent {
  vehicleNumber = '';
  vehicle: Vehicle | null = null;
  notFound = false;
  loading = false;

  constructor(private vehicleService: VehicleService, private router: Router) {}

  check(): void {
    if (!this.vehicleNumber) return;
    this.loading = true;
    this.vehicleService.getByVehicleNumber(this.vehicleNumber.trim()).subscribe({
      next: v => {
        this.vehicle = v;
        this.notFound = !v;
        this.loading = false;
      },
      error: err => {
        console.error('check error', err);
        this.vehicle = null;
        this.notFound = true;
        this.loading = false;
      }
    });
  }

  register(): void {
    this.router.navigate(['/vehicle-form'], { queryParams: { vehicleNumber: this.vehicleNumber }});
  }

  edit(): void {
    if (!this.vehicle) return;
    this.router.navigate(['/vehicle-form'], { queryParams: { vehicleNumber: this.vehicle.vehicleNumber }});
  }

  goQuotes(): void {
    if (!this.vehicle) return;
    this.router.navigate(['/quotes'], { queryParams: { vehicleNumber: this.vehicle.vehicleNumber, userId: this.vehicle.userId }});
  }
}

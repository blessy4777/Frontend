import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { InsuranceService } from '../../services/insurance.service';

@Component({
  selector: 'app-quotes',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="container mt-4">
    <h3>Insurance Quotes</h3>
    <div *ngIf="!vehicleNumber" class="alert alert-warning">No vehicle selected.</div>

    <div *ngIf="quotes?.length">
      <div class="row">
        <div class="col-md-6" *ngFor="let q of quotes">
          <div class="card mb-3">
            <div class="card-body">
              <h5 class="card-title">{{q.providerName}}</h5>
              <p class="mb-1"><strong>Basic:</strong> {{q.basicAmount}}</p>
              <p class="mb-1"><strong>Premium:</strong> {{q.premiumAmount}}</p>
              <button class="btn btn-primary" (click)="select(q)">Select</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div *ngIf="quotes?.length===0" class="alert alert-info">No providers found.</div>
  </div>
  `
})
export class QuotesComponent implements OnInit {
  vehicleNumber = '';
  userId = '';
  quotes: any[] = [];

  constructor(private route: ActivatedRoute, private router: Router, private insuranceService: InsuranceService) {}

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(q => {
      this.vehicleNumber = q.get('vehicleNumber') || '';
      this.userId = q.get('userId') || '';
      if (this.vehicleNumber) this.loadQuotes();
    });
  }

  loadQuotes(): void {
    // use insurance service - fallback to static list if not available
    this.insuranceService.getQuotes(this.vehicleNumber).subscribe({
      next: (list) => this.quotes = list || [],
      error: (err) => { console.error(err); this.quotes = []; }
    });
  }

  select(q: any): void {
    this.router.navigate(['/quote-details'], { queryParams: { provider: q.providerName, vehicleNumber: this.vehicleNumber, plan: 'basic' }});
  }
}

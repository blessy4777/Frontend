import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Vehicle } from '../models/vehicle.model';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {
  private apiUrl = 'http://localhost:8080/api/vehicle';

  constructor(private http: HttpClient) {}

  getByVehicleNumber(vehicleNumber: string): Observable<Vehicle | null> {
    if (!vehicleNumber) return of(null);
    return this.http.get<any>(`${this.apiUrl}/byNumber/${encodeURIComponent(vehicleNumber)}`).pipe(
      map(res => {
        // handle different possible backend shapes
        if (!res) return null;
        if (res.success && res.data) return res.data as Vehicle;
        if (res.vehicle) return res.vehicle as Vehicle;
        return res as Vehicle;
      }),
      catchError(err => {
        console.error('getByVehicleNumber error', err);
        return of(null);
      })
    );
  }

  saveVehicle(vehicle: Vehicle): Observable<Vehicle> {
    if (vehicle.id) {
      return this.http.put<any>(`${this.apiUrl}/update/${vehicle.id}`, vehicle).pipe(
        map(res => res.data || res),
        catchError(err => {
          console.error('update vehicle error', err);
          return throwError(() => err);
        })
      );
    } else {
      return this.http.post<any>(`${this.apiUrl}/register`, vehicle).pipe(
        map(res => {
          if (res && (res.success || res.registered)) {
            return res.data || res.vehicle || res;
          }
          // if backend returns a message but not success flag, still try to return data
          if (res && (res.data || res.vehicle)) return res.data || res.vehicle;
          throw new Error(res?.message || 'Registration failed');
        }),
        catchError(err => {
          console.error('save vehicle error', err);
          return throwError(() => err);
        })
      );
    }
  }
}

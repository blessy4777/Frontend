import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { VehicleService } from './services/vehicle.service';
import { Vehicle } from './models/vehicle.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  vehicleNumber = '';
  vehicle: Vehicle | null = null;
  notFound = false;
  loading = false;

  constructor(private vehicleService: VehicleService, private router: Router) {}

  search(): void {
    if (!this.vehicleNumber) return;
    this.loading = true;
    this.vehicleService.getByVehicleNumber(this.vehicleNumber.trim()).subscribe({
      next: (v) => {
        this.vehicle = v;
        this.notFound = !v;
        this.loading = false;
      },
      error: (err) => {
        console.error('Search error', err);
        this.vehicle = null;
        this.notFound = true;
        this.loading = false;
      }
    });
  }

  goRegister(): void {
    this.router.navigate(['/vehicle-form'], { queryParams: { vehicleNumber: this.vehicleNumber }});
  }

  getPrice(): void {
    if (!this.vehicle) return;
    this.router.navigate(['/quotes'], { queryParams: { vehicleNumber: this.vehicle.vehicleNumber, userId: this.vehicle.userId }});
  }

  editVehicle(): void {
    if (!this.vehicle) return;
    this.router.navigate(['/vehicle-form'], { queryParams: { vehicleNumber: this.vehicle.vehicleNumber }});
  }
}
